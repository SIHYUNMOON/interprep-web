import { WriteClient } from './client'

export default function WritePage() {
  return <WriteClient />
}
